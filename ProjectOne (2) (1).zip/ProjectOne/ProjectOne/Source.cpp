// Hayley Foley, 5/22/24

#include <iostream>
#include <iomanip>

// Clock12 class represents a 12-hour clock
class Clock12 {
private:
    int hours;
    int minutes;
    int seconds;
    std::string period; // "AM" or "PM"

public:
    // Constructor initializes the clock to 12:00:00 AM
    Clock12() : hours(12), minutes(0), seconds(0), period("AM") {}

    // Method to add one hour
    void addHour() {
        hours++;
        if (hours == 12) {
            period = (period == "AM") ? "PM" : "AM";
        }
        else if (hours > 12) {
            hours = 1;
        }
    }

    // Method to add one minute
    void addMinute() {
        minutes++;
        if (minutes >= 60) {
            minutes = 0;
            addHour();
        }
    }

    // Method to add one second
    void addSecond() {
        seconds++;
        if (seconds >= 60) {
            seconds = 0;
            addMinute();
        }
    }

    // Method to display the time
    void display() const {
        std::cout << std::setw(2) << std::setfill('0') << hours << ":"
            << std::setw(2) << std::setfill('0') << minutes << ":"
            << std::setw(2) << std::setfill('0') << seconds << " " << period;
    }
};

// Clock24 class represents a 24-hour clock
class Clock24 {
private:
    int hours;
    int minutes;
    int seconds;

public:
    // Constructor initializes the clock to 00:00:00
    Clock24() : hours(0), minutes(0), seconds(0) {}

    // Method to add one hour
    void addHour() {
        hours = (hours + 1) % 24;
    }

    // Method to add one minute
    void addMinute() {
        minutes++;
        if (minutes >= 60) {
            minutes = 0;
            addHour();
        }
    }

    // Method to add one second
    void addSecond() {
        seconds++;
        if (seconds >= 60) {
            seconds = 0;
            addMinute();
        }
    }

    // Method to display the time
    void display() const {
        std::cout << std::setw(2) << std::setfill('0') << hours << ":"
            << std::setw(2) << std::setfill('0') << minutes << ":"
            << std::setw(2) << std::setfill('0') << seconds;
    }
};

// Function to display both clocks with borders
void displayClocks(const Clock12& clock12, const Clock24& clock24) {
    std::cout << "*************************\t*************************\n";
    std::cout << "*     12-Hour Clock     *\t*     24-Hour Clock     *\n";
    std::cout << "*     ";
    clock12.display();
    std::cout << "       *\t*    ";
    clock24.display();
    std::cout << "           *\n";
    std::cout << "*************************\t*************************\n";
}

// Function to display the menu and get user input with borders
int displayMenu() {
    std::cout << "*************************\n";
    std::cout << "* 1 - Add One Hour      *\n";
    std::cout << "* 2 - Add One Minute    *\n";
    std::cout << "* 3 - Add One Second    *\n";
    std::cout << "* 4 - Exit Program      *\n";
    std::cout << "*************************\n";
    std::cout << "Enter your choice: ";
    int choice;
    std::cin >> choice;
    return choice;
}

int main() {
    Clock12 clock12;
    Clock24 clock24;
    bool exitProgram = false;

    while (!exitProgram) {
        displayClocks(clock12, clock24);
        int choice = displayMenu();

        switch (choice) {
        case 1:
            clock12.addHour();
            clock24.addHour();
            break;
        case 2:
            clock12.addMinute();
            clock24.addMinute();
            break;
        case 3:
            clock12.addSecond();
            clock24.addSecond();
            break;
        case 4:
            exitProgram = true;
            break;
        default:
            std::cout << "Invalid choice. Please try again.\n";
        }
    }

    return 0;
}

